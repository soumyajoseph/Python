#!C:\Users\Soumya Joseph\AppData\Local\Programs\Python\Python35-32\pythonw.exe
import cgi
import cgitb
print('Content-Type:text/html\n\n')
print('hello cgi')
