#!C:\Users\Soumya Joseph\AppData\Local\Programs\Python\Python35-32\pythonw.exe

import cgi
import cgitb
import os

print ("Content-type: text/html\r\n\r\n")
print ("<font size=+1>Environment</font><\br>")
for param in os.environ.keys():
   print ("<b>%20s</b>: %s<\br>" % (param, os.environ[param]))
